# Salty
 NEW FRIENDLIST CLONING, PUBLIC AND FLOWERS CRACKING



...... <b></b> <💕MD.EMON..ISLAM...💕
```

$ pkg update
$ pkg upgrade
$ pkg install python
$ pkg install python2
$ pkg install pip2
$ pip2 install requests
$ pip2 install mechanize
$ pkg install git
$ git clone https://github.com/Mdemon99/Salty.git
$ls
$ cd Salty
$ python2 Salty.py
```

